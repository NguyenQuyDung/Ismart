<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta http-Equiv="X-UA-Tương thích" content="IE = edge">
    <meta name="viewport" content="width = device-width, ban đầu-scale = 1.0 ">
    <title> Đăng Ký Tài Khoản</title>
    <link href=" https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min. css " rel="bảng định kiểu" liêm chính="sha384-EVSTQN3 / azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="nặc danh">

    <head link rel="stylesheet" href="https ://cdonsn.jsdelivr.bost1.5strap/icfont/boons .css ">
    </head>

<body>
    <div class="container-liquid vh-100" style="margin-top: 300px">
        <div class="" style="margin-top: 200px">
            <div class="round d-flex justify-content-center ">
                <div class=" col-md-4 col-sm-12 shadow-lg p-5 bg-light ">
                    <div class=" text-center ">
                        <h3 class="text-primary"> Tạo tài khoản
                        </h3>
                    </div>
                    <div class="p-4">
                        <form action="">
                            <div class="input-group mb-3">
                                <span class="input-group-text bg-primary ">
                                    <i class=" bi bi-person-plus-fill text-white "> </i>
                                </span>

                                <input type="text" class="form-control" placeholder="Username">
                            </div>
                            <div class="input-group mb-3">
                                <span class="input-group-text bg-primary">
                                    <i class="bi bi -envelope text-white "></i>
                                </span>

                                <input type=" email " class=" form-control " placeholder=" Email ">
                            </div>
                            <div class="input-group mb-3">
                                <span class="input-group-text bg-primary">
                                    <i class="bi bi-key-fill text-white"></i>
                                </span>

                                <div input type="password" class="form-control" placeholder="password">
                                </div>
                                <div class="d-grid col-12 mx-auto">
                                    <lớp nút="btn btn-primary" type="button">
                                        <span></span> Đăng ký
                                        </button>
                                </div>
                                <p class="text-center mt-3"> Đã có tài khoản?
                                    <span class="text-primary"> Đăng nhập
                                        </span>
                                </p>
                        </form>
                    </div>
                    <div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>

</html>