@extends('layouts.user')
@section('content')
<!-- <h4>Liên Hệ</h4>
<p>Các bạn có nhu cầu liên hệ quảng cáo banner, tài trợ, thắc mắc, góp ý vui lòng liên hệ:</p>
<b>– Email: info@top10tphcm.com
– Hotline: 0888 889968
– Địa chỉ: 72-74 Nguyễn Thị Minh Khai, Phường 6, Quận 3, TPHCM</b> -->
<div style=" background:#f7f7f7;">
    <h1 style="text-align: center;padding:10px 0px; margin:0px; padding-top:50px;"><span style="font-size: 18pt;"><strong>TH&Ocirc;NG TIN LI&Ecirc;N HỆ</strong></span></h1>
</div>
<div id="main-content-wp" class="clearfix detail-blog-page" style="display:flex;">
    <div class="wp-inner" style="margin-top:30px;">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d35688.76115476395!2d105.81629029325296!3d21.019441738168798!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3135ab9bd9861ca1%3A0xe7887f7b72ca17a9!2zSMOgIE7hu5lpLCBIb8OgbiBLaeG6v20sIEjDoCBO4buZaSwgVmnhu4d0IE5hbQ!5e0!3m2!1svi!2s!4v1661749417891!5m2!1svi!2s" width="300" height="450" style="border:0; width:740px !important; margin-left:180px;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </div>
    <div style="width: 500px;
    margin-right: 120px !important; ">
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px;"><br /><span style="font-size: 14pt;">Tư vấn &amp; Hỗ Trợ trực tuyến : </span><br /><span style="font-size: 14pt; padding-top:8px; display:block;">Hoạt Động Từ (08:30 - 12:00; 13:30 - 21:30)</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px; line-height: 1;"><span style="font-size: 14pt;">Số điện thoại li&ecirc;n hệ : 0345910508</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px; line-height: 1;"><span style="font-size: 14pt;">Facebook : Nguyễn Qúy Dũng</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px; line-height: 1;"><span style="font-size: 14pt;">Youtobe : Dũng TV</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px; line-height: 1;"><span style="font-size: 14pt;">H&agrave; Nội : (034).5910508</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px; line-height: 1;"><span style="font-size: 14pt;">TP.HÀ NỘI : (034).5910508</span></p>
        <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px;"><span style="font-size: 14pt;">Email hỗ trợ b&aacute;n h&agrave;ng Online, doanh nghiệp : <a href="mailto:dn5678853@gmail.com">dn5678853@gmail.com</a></span></p>
   <p style="font-size: 18pt; font-family: arial, helvetica, sans-serif;padding:10px 0px;"><span style="font-size: 14pt;">Mọi thông tin chi tiết về dịch vụ làm chăm sóc khách hàng , hãy liên hệ những thông tin bên trên Xin cảm ơn !</span></p>
    </div>
</div>
@endsection